import React, { useState, useEffect } from 'react';
import timesheetService from '../services/timesheetService';
import './ViewTimesheet.css';
import { useAuth } from '../context/AuthContext';

function ViewTimesheet() {
    const [timesheets, setTimesheets] = useState([]);
    const [filteredTimesheets, setFilteredTimesheets] = useState([]);
    const [selectedDate, setSelectedDate] = useState(null);
    const { empId } = useAuth();

    useEffect(() => {
        console.log('Fetching timesheets for empId:', empId);
        loadTimesheets();
    }, [empId]);

    const loadTimesheets = async () => {
        try {
            const response = await timesheetService.getTimesheets();
            console.log('Timesheets fetched:', response.data);
            const employeeTimesheets = response.data.filter(t => t.emp_id === empId);
            console.log('Filtered timesheets:', employeeTimesheets);
            setTimesheets(employeeTimesheets);
            setFilteredTimesheets(employeeTimesheets);
        } catch (error) {
            console.error("Error loading timesheets:", error);
        }
    };

    const handleDateChange = (e) => {
        const inputDate = e.target.value;
        if (inputDate) {
            const date = new Date(inputDate);
            if (!isNaN(date.getTime())) {
                const formattedDate = date.toISOString().split('T')[0];
                setSelectedDate(formattedDate);

                const filtered = timesheets.filter(t => t.date === formattedDate);
                setFilteredTimesheets(filtered);
            } else {
                console.error('Invalid date value');
                setFilteredTimesheets([]);
            }
        } else {
            handleShowAll();
        }
    };

    const handleShowAll = () => {
        setSelectedDate(null);
        setFilteredTimesheets(timesheets);
    };

    const formatTimestamp = (timestamp) => {
        const date = new Date(timestamp);
        // Format the date as YYYY-MM-DD and time as HH:MM:SS
        return `${date.toISOString().split('T')[0]} ${date.toTimeString().split(' ')[0]}`;
    };

    const renderTimesheetDetails = () => {
        if (!filteredTimesheets.length) return <p>No entries available</p>;

        return (
            <div className="timesheet-detailss">
                <h3>{selectedDate ? `Timesheet Details for ${selectedDate}` : 'All Timesheet Entries'}</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Employee ID</th>
                            <th>Employee Name</th>
                            <th>Project Name</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Total Hours</th>
                            <th>Timestamp</th> {/* New column for timestamp */}
                            <th>Comments</th>
                            <th>Lead Approval</th>
                            <th>Manager Approval</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        {filteredTimesheets.map((entry, idx) => (
                            <tr key={idx}>
                                <td>{entry.date}</td>
                                <td>{entry.emp_id}</td>
                                <td>{entry.emp_name}</td>
                                <td>{entry.project_name}</td>
                                <td>{entry.start_time}</td>
                                <td>{entry.end_time}</td>
                                <td>{entry.total_hours}</td>
                                <td>{formatTimestamp(entry.timestamp)}</td> {/* Format and display timestamp */}
                                <td>{entry.comments}</td>
                                <td>{entry.lead_approval}</td>
                                <td>{entry.manager_approval}</td>
                                
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        );
    };

    return (
        <div className="view-timesheet-container">
            <h2>Timesheet Entries</h2>
            <div className="date-selector">
                <input
                    type="date"
                    onChange={handleDateChange}
                />
                <button onClick={handleShowAll}>Show All</button>
            </div>
            {renderTimesheetDetails()}
        </div>
    );
}

export default ViewTimesheet;
