import { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [empId, setEmpId] = useState(localStorage.getItem('empId') || null);

    const login = (id) => {
        setEmpId(id);
        localStorage.setItem('empId', id);
    };

    const logout = () => {
        setEmpId(null);
        localStorage.removeItem('empId');
        localStorage.removeItem('token');
    };

    return (
        <AuthContext.Provider value={{ empId, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
