# from django.urls import path
# from .views import RegisterView, LoginView, TimesheetView

# urlpatterns = [
#     path('register/', RegisterView.as_view(), name='register'),
#     path('login/', LoginView.as_view(), name='login'),
#     path('timesheet/', TimesheetView.as_view(), name='timesheet'),
#     # Add other URLs here
# ]
from django.urls import path
from .views import RegisterView, LoginView, TimesheetView, LeadTimesheetView,ManagerTimesheetView,EmployeeDetailView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('timesheet/', TimesheetView.as_view(), name='timesheet'),
    # path('lead-timesheets/', LeadTimesheetView.as_view(), name='lead-timesheets'),
    # path('lead-timesheets/<int:pk>/', LeadTimesheetView.as_view(), name='lead-timesheet-detail'),  # Added for PUT requests
    path('lead-timesheets/', LeadTimesheetView.as_view(), name='lead-timesheets'),
    path('lead-timesheets/<int:timesheet_id>/', LeadTimesheetView.as_view(), name='lead-timesheet-update'),
    # path('manager-timesheets/', ManagerTimesheetView.as_view(), name='manager_timesheets'),
    # path('manager-timesheets/<int:timesheet_id>/', ManagerTimesheetView.as_view(), name='manager_timesheet_detail'),
    path('manager-timesheets/', ManagerTimesheetView.as_view(), name='manager-timesheets-list'),
    path('manager-timesheets/<int:timesheet_id>/', ManagerTimesheetView.as_view(), name='manager-timesheet-detail'),
    path('employees/<str:emp_id>/', EmployeeDetailView.as_view(), name='employee-detail'),
]

